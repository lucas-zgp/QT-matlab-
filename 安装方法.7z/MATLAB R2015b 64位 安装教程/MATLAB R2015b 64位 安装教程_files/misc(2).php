document.write('<ul>');document.writeln('<li><img src="\/attachment\/image\/2021\/0625\/144526_25309479.jpg"><\/img><\/li>');
document.write('</ul>');