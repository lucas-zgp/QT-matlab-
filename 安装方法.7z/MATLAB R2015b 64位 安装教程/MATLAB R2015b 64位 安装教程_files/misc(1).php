document.write('<ul>');document.writeln('<li>');

var cpro_id = "u6370261";

document.writeln('<s'+'cript type="text/javascript" src="//cpro.baidustatic.com/cpro/ui/cm.js"><\/s'+'cript>');
document.writeln('<\/li>');
document.write('</ul>');